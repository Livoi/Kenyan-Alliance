/**
 * Created by Izone Ltd on 2/11/2016.
 */
(function () {
    'use strict';

    /**
     * Created by Administrator on 02/02/2015.
     */
    angular.module("app").factory('ProcessInstanceHistoryService', ['$http', '$q', fnProcessInstanceHistoryService]);
    var processkey = "Staff-Leave-Process";
    var processinstanceurl = "http://localhost:8080/engine-rest/history/process-instance";
    function fnProcessInstanceHistoryService($http, $q) {

        //Get Controller Title
        function fnGetControllerTitle() {
            return "Cases Home";
        }

        function fnGetCreateCaseTitle() {
            return "New Case";
        }

        function fnGetProcessInstanceHistory() {
            var dfd = $q.defer();
            var queryfilter = "?processDefinitionName="+processkey+"&finished=true";
            var restUrl = processinstanceurl + queryfilter;
            //alert(restUrl);
            $http({
                method: "GET",
                url: restUrl,
                headers: { "Accept": "application/json;odata=verbose" }
            }).success(function (data) {
                //alert(JSON.stringify(data));
                var formattedcase = fnFormatProcessInstancesHistory(data);
                dfd.resolve(formattedcase);
            }).error(function (data) {
                //alert(JSON.stringify(data));
                dfd.reject("error getting cases");
            });
            return dfd.promise;
        }


        function fnFormatProcessInstanceHistory(casedata) {

            var acase = {

                Id: casedata.id

            };
            //alert("fnFormatProcessInstanceHistory: " + JSON.stringify(acase));
            return acase;
        }

        function fnFormatProcessInstancesHistory(data) {
            var casesarray = [];
            angular.forEach(data, function (casedata) {
                var acase = fnFormatProcessInstanceHistory(casedata);
                casesarray.push(acase);
            });
            return casesarray;
        }


        //Task Service API
        return {
            getTitle: fnGetControllerTitle,
            getCreateCaseTitle: fnGetCreateCaseTitle,
            getProcessInstanceHistory: fnGetProcessInstanceHistory
        }
    }
})();
