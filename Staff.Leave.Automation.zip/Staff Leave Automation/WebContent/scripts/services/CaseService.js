(function () {
    'use strict';

    /**
     * Created by Administrator on 02/02/2015.
     */
    angular.module("app").factory('CaseService', ['$http', '$q', fnCaseService]);
	var processkey = "Staff-Leave-Process";
	var createupdatecaselisturl = "http://localhost:8080/engine-rest/process-definition/key/"+processkey+"/start";
    var business_key = "staff_leave_process";
    function fnCaseService($http, $q) {

        //Get Controller Title
        function fnGetControllerTitle() {
            return "Cases Home";
        }
        
        function fnGetCreateCaseTitle() {
            return "New Case";
        }

        function fnGetCaseByGuid(itemid) {
            var dfd = $q.defer();
            var restUrl = "http://localhost:8080/engine-rest/process-instance/"+ itemid +"/variables?deserializeValues=false";
            //alert(restUrl);
            $http({
                method: "GET",
                url: restUrl,
                headers: { "Accept": "application/json;odata=verbose" }
            }).success(function (data) {
                //alert(JSON.stringify(data));
                var formattedcase = fnFormatCaseDetailFromJSON(data);
                dfd.resolve(formattedcase);
            }).error(function (data) {
                //alert(JSON.stringify(data));
                dfd.reject("error getting cases");
            });
            return dfd.promise;
        }

        // Get History Process Instance Variables
        function fnGetHistoryVariables(itemid) {
            //alert(JSON.stringify(itemid));
            var dfd = $q.defer();
            var queryfilter = "?processInstanceId="+itemid+"&deserializeValues=false";
            var restUrl = "http://localhost:8080/engine-rest/history/variable-instance"+ queryfilter;
            //alert(restUrl);
            $http({
                method: "GET",
                url: restUrl,
                headers: { "Accept": "application/json;odata=verbose" }
            }).success(function (data) {
                //alert(JSON.stringify(data));
                var formattedcase = fnFormatVariablesHistoryFromJSON(data);
                //alert(JSON.stringify(formattedcase));
                dfd.resolve(formattedcase);
            }).error(function (data) {
                //alert(JSON.stringify(data));
                dfd.reject("error getting cases");
            });
            return dfd.promise;
        }
        
      //Get Cases
        function fnGetCases() {
            var dfd = $q.defer();
            var restUrl = "CaseDetailController?processinstanceid=null&taskroute=cases";
			//alert(restUrl);
            $http({
                method: "GET",
                url: restUrl,
                headers: { "Accept": "application/json;odata=verbose" }
            }).success(function (data) {            	
                var formattedcases = fnFormatCasesFromJSON(data);
                dfd.resolve(formattedcases);
                //alert("fnGetCases:" + JSON.stringify(formattedcases));
            }).error(function (data) {
                dfd.reject("error getting cases");
            });
            return dfd.promise;
        }
        
      //Get Single Case
        function fnGetCase(processinstanceid) {
            var dfd = $q.defer();
            var restUrl = "CaseDetailController?processinstanceid="+processinstanceid+"&taskroute=casedetail";
			//alert(restUrl);
            $http({
                method: "GET",
                url: restUrl,
                headers: { "Accept": "application/json;odata=verbose" }
            }).success(function (data) {            	
                var formattedcases = fnFormatCaseFromJSON(data);
                dfd.resolve(formattedcases);
                //alert("fnGetCases:" + JSON.stringify(formattedcases));
            }).error(function (data) {
                dfd.reject("error getting cases");
            });
            return dfd.promise;
        }
        
      //Get Time Bank Details
        function fnGetTimeBankDetails() {
            var dfd = $q.defer();
            var restUrl = "CaseDetailController?staffId=1&taskroute=timebank";
			//alert(restUrl);
            $http({
                method: "GET",
                url: restUrl,
                headers: { "Accept": "application/json;odata=verbose" }
            }).success(function (data) {            	
                var formattedcases = fnFormatCaseFromJSON(data);
                //alert("fnGetCases:" + JSON.stringify(data));
                dfd.resolve(formattedcases);
                //alert("fnGetCases:" + JSON.stringify(formattedcases));
            }).error(function (data) {
                dfd.reject("error getting cases");
            });
            return dfd.promise;
        }

        function fnFormatCaseDetailFromJSON(casedata) {
           // alert("fnFormatCaseDetailFromJSON:" + JSON.stringify(casedata));
            //alert("fnFormatCaseDetailFromJSON:" + casedata.StaffDesignation.value);
            var acase = {

                StaffName: casedata.StaffName.value,
                StaffDesignation: casedata.StaffDesignation.value,
                RequestTypeLU: casedata.RequestTypeLU.value,
                Description: casedata.Description.value,
                StartDate: casedata.StartDate.value,
                ReturnDate: casedata.ReturnDate.value,
                HoursRequested: casedata.HoursRequested.value

            };
            //alert("fnFormatCaseFromJSON: " + JSON.stringify(acase));
            return acase;
        }

        function fnFormatVariableHistoryFromJSON(casedata) {
            var acase = {
                ColumnName: casedata.name,
                ColumnValue: casedata.value

            };
            return acase;
        }

        function fnFormatVariablesHistoryFromJSON(data) {
            var casesarray = [];
            angular.forEach(data, function (casedata) {
                var acase = fnFormatVariableHistoryFromJSON(casedata);
                casesarray.push(acase);
            });
            return casesarray;
        }

		function fnFormatCaseFromJSON(casedata) {
			
			var acase = {
					
				Id: casedata.caseid,
				StaffName: casedata.staffname,
				StaffDesignation: casedata.staffdesignation,
				RequestTypeLU: casedata.requesttype,
				StartDate: casedata.startdate,
				ReturnDate: casedata.enddate,
				HoursRequested: casedata.hoursrequested,
				Description: casedata.description,
				CaseReferenceLu: casedata.casereferncelu,
				LeaveDaysAllocated: casedata.leavedaysallocated
				
			};
			return acase;
		}

        function fnFormatCasesFromJSON(data) {
            var casesarray = [];
            angular.forEach(data, function (casedata) {
				var acase = fnFormatCaseFromJSON(casedata);
                casesarray.push(acase);
            });
            return casesarray;
        }
        
		function fnFormatResponseFromJSON(casedata) {
			
			var acase = {
					
				Id: casedata.id,
				DefinitionId: casedata.definitionId,
				BusinessKey: casedata.businessKey				
			};
			return acase;
		}
		

        // Get Process Instance History Variables
        function fnGetProcessHistoryVariables(dataarray)
        {
            var dfd = $q.defer();
            angular.forEach(dataarray, function (item) {

                fnGetHistoryVariables(item.Id);
            });
            //risky to return done for items
            dfd.resolve("done");
            return dfd.promise;
        }

        function fnTestCreateCase(acase) {
            alert("Alas CaseService fnTestCreateCase(acase) Works!" + acase.Name);
        }


        //Create Case Details
        function fnCreateCaseDetails(acase,processinstanceid) {
            var dfd = $q.defer();
            var url = "CaseDetailController";
            var casedata = 
			{				           		
        		"StaffName": acase.StaffName,
				"StaffDesignation": acase.StaffDesignation,
				"RequestType": acase.RequestTypeLU,
				"Description": acase.Description,
				"StartDate": acase.StartDate,
				"EndDate": acase.ReturnDate,
				"HoursRequested": String(acase.HoursRequested),
				"CreateGuid": processinstanceid
			};
            //alert("POSTED:" +JSON.stringify(casedata)); 
            $http.defaults.headers.post['Content-Type'] = "application/json";
            $http.post(url, casedata).success(function (data) {       	
            	alert("POSTED:" +JSON.stringify(data));            	
               /*var formattedcase = fnFormatCaseFromJSON(data);
                dfd.resolve(formattedcase);
				alert("formattedcase" +JSON.stringify(formattedcase));*/
            }).error(function (data) {
				alert(JSON.stringify(data));
                dfd.reject("error creating case");
            });

            return dfd.promise;
        }
        
      //Create Case
        function fnCreateCase(acase) {
            var dfd = $q.defer();
            var casedata = 
			{
				"variables": {
					/*"StaffName": {"value":acase.StaffName,"type":"String"},
					"StaffDesignation":{"value":acase.StaffDesignation,"type":"String"},
					"RequestTypeLU":{"value":acase.RequestTypeLU,"type":"String"},
					"Description":{"value":acase.Description,"type":"String"},
					"StartDate":{"value":acase.StartDate,"type":"String"},*/
					"CreateGuid":{"value":acase.CreateGuid,"type":"String"},
					"HoursRequested":{"value":acase.HoursRequested,"type":"Double"}
				},
				"businessKey" : business_key
			};
			//alert("fnCreateCase: " + JSON.stringify(casedata));

            $http.defaults.headers.post['Content-Type'] = "application/json";
            $http.post(createupdatecaselisturl, casedata).success(function (data) {             	
                var formattedcase = fnFormatResponseFromJSON(data);
                dfd.resolve(formattedcase);
				//alert("formattedcase" +JSON.stringify(formattedcase));
            }).error(function (data) {
				alert(JSON.stringify(data));
                dfd.reject("error creating case");
            });

            return dfd.promise;
        }

        //Task Service API
        return {
            getTitle: fnGetControllerTitle,
            getCreateCaseTitle: fnGetCreateCaseTitle,
            getCases: fnGetCases,
            getCase: fnGetCase,
            getTimeBankDetails: fnGetTimeBankDetails,
            createCase: fnCreateCase,
            createCaseDetails: fnCreateCaseDetails,
            getCaseByGuid: fnGetCaseByGuid,
            getHistoryVariables: fnGetHistoryVariables,
            getProcessHistoryVariables: fnGetProcessHistoryVariables
        }
    }
})();
