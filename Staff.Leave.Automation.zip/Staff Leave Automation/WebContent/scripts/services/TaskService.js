(function () {
    'use strict';

    /**
     * Created by Administrator on 02/02/2015.
     */
    angular.module("app").factory('TaskService', ['$http', '$q', fnTaskService]);

    var tasklisturl = "http://localhost:8080/engine-rest/task";
    var taskhistoryurl = "http://localhost:8080/engine-rest/history/task"
    var relatedCaseListId = "Staff-Leave-Process";
    function fnTaskService($http, $q) {

        //Get Controller Title
        function fnGetControllerTitle() {
            return "Tasks Home";
        }

        function fnGetDigest() {
            return $('#__REQUESTDIGEST').val();
        }

        //Get Tasks
        function fnGetTask(taskid) {
            var dfd = $q.defer();
             var queryfilter = "?processInstanceId="+taskid+"";
             var restUrl = tasklisturl + queryfilter;

             $http({
             method: "GET",
             url: restUrl,
             headers: { "Content-Type": "application/json" }
             }).success(function (data) {
             var formattedtasks = fnFormatTasksFromJSON(data);
             //alert("JSON DATA:" + JSON.stringify(data));
             dfd.resolve(formattedtasks);
             }).error(function (data) {
             dfd.reject("error getting task");
             });
             return dfd.promise;
        }

        //Get Task History
        function fnGetTaskHistory(taskid) {
            var dfd = $q.defer();
            var queryfilter = "?processDefinitionName="+relatedCaseListId+"&finished=true&sortBy=endTime&sortOrder=desc";//?processDefinitionName=Staff-Leave-Process&finished=true
            var restUrl = taskhistoryurl + queryfilter;

            $http({
                method: "GET",
                url: restUrl,
                headers: { "Content-Type": "application/json" }
            }).success(function (data) {
                var formattedtasks = fnFormatTasksFromJSON(data);
                //alert("JSON DATA:" + JSON.stringify(data));
                dfd.resolve(formattedtasks);
            }).error(function (data) {
                dfd.reject("error getting task");
            });
            return dfd.promise;
        }

        function fnGetTasks(caseid) {
            var dfd = $q.defer();

            var queryfilter = "?processDefinitionName=Staff-Leave-Process";
            var restUrl = tasklisturl + queryfilter;

            $http({
                method: "GET",
                url: restUrl,
                headers: { "Content-Type": "application/json; odata=verbose" }
            }).success(function (data) {
                var formattedtasks = fnFormatTasksFromJSON(data);
                //alert("JSON DATA:" + JSON.stringify(data));
                dfd.resolve(formattedtasks);
            }).error(function (data) {
                dfd.reject("error getting task");
            });
            return dfd.promise;
        }


        //
        function fnFormatTaskFromJSONDetail(taskdata){
            var atask = {
                Id: taskdata.ID,
                Name: taskdata.Title,
                Status: taskdata.Status
            };
            return atask;
        }


        function fnFormatTaskFromJSON(taskdata){
            //alert(JSON.stringify(taskdata.Editor.Title));

            var atask = {
                id: taskdata.id,
                name: taskdata.name,
                created: taskdata.created,
                processInstanceId: taskdata.processInstanceId,
                MangerApprovalDecision: taskdata.MangerApprovalDecision,
                MangerApprovalComments: taskdata.MangerApprovalComments,
                startTime: taskdata.startTime,
                endTime: taskdata.endTime

            };
            //alert("atask:" + atask.name);
            return atask;

        }

        //Convert Data from JSON to Task Object
        function fnFormatTasksFromJSON(data) {
            var tasksarray = [];
            angular.forEach(data, function (taskdata) {

                var atask = fnFormatTaskFromJSON(taskdata);
                    tasksarray.push(atask);
            });
            return tasksarray;
        }

        //Convert Data from Task Object to JSON
        function fnFormatTasksToJSON(task) {
            var taskjsonobject = {
                Id: task.ID,
                Name: task.Title,
                Status: task.Status,
                TaskOutcome: task.TaskOutcome,
                PercentComplete: task.PercentComplete,
                Created: task.Created,
                Modified: task.Modified
            };
            return taskjsonobject;
        }

        function fnApproveTask(taskitem) {
            var dfd = $q.defer();
            var taskurl = tasklisturl + "/"+ taskitem.TaskId + "/complete";
            var taskdata = {

                "variables": {
                    "MangerApprovalDecision": {"value":"Approved","type":"String"},
                    "MangerApprovalComments": {"value":taskitem.MangerApprovalComments,"type":"String"}
                }

            };
           // alert("fnApproveTask: " +JSON.stringify(taskdata));

            $http.defaults.headers.post['Content-Type'] = "application/json";

            $http.post(taskurl, taskdata).success(function (data) {
                var formattedtasks = fnFormatTasksFromJSON(data);
                dfd.resolve(formattedtasks);
            }).error(function (data) {
                dfd.reject("error getting tasks");
            });

            return dfd.promise;
        }

        function fnRejectTask(taskitem) {
            var dfd = $q.defer();
            var taskurl = tasklisturl + "/"+ taskitem.TaskId + "/complete";
            //http://localhost:8080/engine-rest/task/95af1b22-3a7a-11e5-85b6-dafa20524153/complete
            var taskdata = {

                "variables": {
                    "MangerApprovalDecision": {"value":"Rejected","type":"String"},
                    "MangerApprovalComments": {"value":taskitem.MangerApprovalComments,"type":"String"}
                }

            };

            $http.defaults.headers.post['Content-Type'] = "application/json;odata=verbose";

            $http.post(taskurl, taskdata).success(function (data) {
                var formattedtasks = fnFormatTasksFromJSON(data);
                dfd.resolve(formattedtasks);
            }).error(function (data) {
                dfd.reject("error getting tasks");
            });

            return dfd.promise;
        }

        //Task Service API
        return {
            getTitle: fnGetControllerTitle,
            getTasks: fnGetTasks,
            getTaskHistory: fnGetTaskHistory,
            getTask: fnGetTask,
            approveTask: fnApproveTask,
            rejectTask: fnRejectTask,
            getDigest: fnGetDigest
        }
    }
})();
