(function () {
    'use strict';

    angular.module("app").controller("CreateCaseCtrl", ['$scope', '$rootScope', '$location', '$filter', 'CaseService', fnCreateCaseCtrl]);

    function fnCreateCaseCtrl($scope, $rootScope, $location, $filter, CaseService) {

        $scope.initializeController = function () {

			$scope.Id = "";
			$scope.StaffName = "";
			$scope.StaffDesignation = "";
			$scope.RequestTypeLU = "";
			$scope.RequestTypeLUSelected = "";
			$scope.Description = "";
			$scope.Startdate = "";
			$scope.Returndate = "";
			$scope.HoursRequested = "";
			$scope.CaseCreated = false;
			$scope.SubmittedFlag = false;
			$scope.RequestTypeOptions = [
				{ label: 'Ordinary Vacation', value: 'Ordinary Vacation' },
				{ label: 'Bereavement', value: 'Bereavement' },
				{ label: 'Personal Days', value: 'Personal Days' },
				{ label: 'Sick Days', value: 'Sick Days' }
			  ];
				
			$scope.CreateGuid = uuid.v4().toString();

        }

		$scope.$watch(function() {

			$scope.StartDate= $filter('date')($scope.Startdate ,'dd/MM/yyyy');
			$scope.ReturnDate= $filter('date')($scope.Returndate ,'dd/MM/yyyy');

			var dt1 = $scope.StartDate.split('/'),
			 dt2 = $scope.ReturnDate.split('/'),
			 one = new Date(dt1[2], dt1[1]-1, dt1[0]),
			 two = new Date(dt2[2], dt2[1]-1, dt2[0]);

			 var millisecondsPerDay = 1000 * 60 * 60 * 24;
			 var millisBetween = two.getTime() - one.getTime();
			 var days = millisBetween / millisecondsPerDay;
		 return days;
		}, function(newValue) {
			$scope.HoursRequested = newValue * 8;
		});
				
		   
        $scope.createCase = function () {

			$scope.Title = "New Case Creation - ";
            var acase = {
					Id: $scope.Id,
                    StaffName: $scope.StaffName,
					StaffDesignation: $scope.StaffDesignation,
					RequestTypeLU: $scope.RequestTypeLUSelected.value,
					Description: $scope.Description,
					StartDate: $scope.StartDate,
					ReturnDate: $scope.ReturnDate,
					HoursRequested: $scope.HoursRequested
					//CreateGuid: $scope.CreateGuid
                };
			//alert("fnFormatCaseFromJSON: " + JSON.stringify(acase));
			$scope.SubmittedFlag = true;
			$scope.Display = " - Successful!";
            CaseService.createCase(acase).then(function (newcase) {            	
				//alert("CaseService.createCase");
                $scope.Id = newcase.Id;
				//$scope.Display = " Successful!";
				CaseService.createCaseDetails(acase,$scope.Id).then(function (newcase) {
            		 $scope.CaseCreated = true;     				
                     $scope.Display = " Successful!";                    
                }, function ()
                {
                	$scope.CaseCreated = false;
                    $scope.Display = " Create Case Details Failed!";
                });
            }, function ()
            {
				$scope.SubmittedFlag = false;
                $scope.CaseCreated = false;
                $scope.Display = "Failed!";
            });
			  
        }
		
    }




})();