(function () {
    'use strict';

    angular.module("app").controller("CaseCtrl", ['$scope', '$location', 'CaseService', fnCasesCtrl]);

    function fnCasesCtrl($scope, $location, CaseService) {

        $scope.Title = CaseService.getTitle();
			
        $scope.getCases = function () {
			
            CaseService.getCases().then(function (cases) {
            	
                $scope.Cases = cases;
                
           }, function () { $scope.Display = "Error!";alert("Called -CaseService!"); });
        }
		//$scope.Cases = [];
        $scope.getCases();
        
    }
})();