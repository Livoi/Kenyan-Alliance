(function () {
    'use strict';
    angular.module("app").controller("TasksCtrl", ['$scope', '$rootScope', '$location', 'TaskService', fnTasksCtrl]);

    function fnTasksCtrl($scope, $rootScope, $location, TaskService) {

        $scope.Title = TaskService.getTitle();

        $scope.approveTask = function (taskid) {
            TaskService.approveTask(taskid).then(function (atask) {
				alert("Task Approved!");
            }, function () { $scope.Display = "Error!" });
        }

        $scope.rejectTask = function (taskid) {
            TaskService.rejectTask(taskid).then(function (atask) {
				alert("Task Rejected!");
            }, function () { $scope.Display = "Error!" });
        }

        $scope.getTasks = function () {
            TaskService.getTasks().then(function (tasks) {

                $scope.Tasks = tasks;
                //alert("Tasks:" +JSON.stringify($scope.Tasks));
            }, function () { $scope.Display = "Error!" });

        }

        $scope.getTaskHistory = function () {
            TaskService.getTaskHistory().then(function (taskshistory) {

                $scope.TasksHistory = taskshistory;

                //alert("Tasks:" +JSON.stringify($scope.TasksHistory));
            }, function () { $scope.Display = "Error!" });

        }




		//$scope.Tasks=[];
         $scope.getTasks();
         $scope.getTaskHistory();

        //$scope.Digest = TaskService.getDigest();
    }
})();