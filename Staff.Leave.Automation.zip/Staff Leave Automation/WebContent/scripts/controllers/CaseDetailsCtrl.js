(function () {
    'use strict';

    angular.module("app").controller("CaseDetailsCtrl", ['$scope', 'CaseService', '$routeParams', fnCaseDetailsCtrl]);

    function fnCaseDetailsCtrl($scope, CaseService, $routeParams) {

       $scope.CaseId = $routeParams.processinstanceid;
       
       //alert("$scope.CaseId: " +$scope.CaseId);
			
        $scope.getCases = function () {
			
            CaseService.getCase($scope.CaseId).then(function (casedata) {
            	
            	$scope.TheCase = casedata;
            	
            	//alert("$scope.TheCase: " +JSON.stringify($scope.TheCase));
                
           }, function () { $scope.Display = "Error!";alert("Called -CaseService!"); });
        }
		//$scope.Cases = [];
        $scope.getCases();
        
    }
})();