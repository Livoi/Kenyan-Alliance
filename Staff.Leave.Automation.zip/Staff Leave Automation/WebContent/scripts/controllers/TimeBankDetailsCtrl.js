(function () {
    'use strict';

    angular.module("app").controller("TimeBankDetailsCtrl", ['$scope', '$location', 'CaseService', fnTimeBankDetailsCtrl]);

    function fnTimeBankDetailsCtrl($scope, $location, CaseService) {

       
        $scope.getTimeBankDetails = function () {
			
            CaseService.getTimeBankDetails().then(function (timebankdetails) {
            	
                $scope.TimeBankDetails = timebankdetails;              
                
           }, function () { $scope.Display = "Error!";alert("Called -CaseService!"); });
        }
		//$scope.Cases = [];
        $scope.getTimeBankDetails();
        
    }
})();