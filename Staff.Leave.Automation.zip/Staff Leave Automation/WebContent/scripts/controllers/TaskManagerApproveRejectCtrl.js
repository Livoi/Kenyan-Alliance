(function () {
    'use strict';

angular.module("app").controller("TaskManagerApproveRejectCtrl",['$scope','$routeParams','TaskService','CaseService',fnTaskManagerApproveRejectCtrl])


 function fnTaskManagerApproveRejectCtrl($scope,$routeParams,TaskService,CaseService) {

    $scope.initializeController = function () {
        $scope.TaskId = $routeParams.taskid;
		$scope.ProcessInstanceId = $routeParams.processinstanceid;
		$scope.SubmittedFlag = false;
		$scope.MangerApprovalDecision ="";
		$scope.MangerApprovalComments ="";
		
		TaskService.getTask($routeParams.processinstanceid).then(
				function(taskdata)
				{
					$scope.TheTask = taskdata;

					//Get the Related Case
					CaseService.getCase($scope.ProcessInstanceId).then(
					function(casedata)
					{
						$scope.TheCase = casedata;
					}
					);
				}
				);

		$scope.approveTask = function()
		{
			var caseupdatedata =
			{
					"MangerApprovalComments": $scope.MangerApprovalComments,
					"ProcessInstanceId": $routeParams.processinstanceid,
					"TaskId": $routeParams.taskid

			};
			//alert("declineExtraDaysTask:" + JSON.stringify(caseupdatedata));
			TaskService.approveTask(caseupdatedata).then(function (atask) {

					$scope.Display = " - Successful!";

				},
				function ()
				{
					$scope.Display = " - Failed!";
				}
			);
		}

		$scope.rejectTask = function()
		{
			var caseupdatedata =
			{
				"MangerApprovalComments": $scope.MangerApprovalComments,
				"ProcessInstanceId": $routeParams.processinstanceid,
				"TaskId": $routeParams.taskid

			};
			//alert("declineExtraDaysTask:" + $scope.TaskId);
			TaskService.rejectTask(caseupdatedata).then(function (atask) {

					$scope.Display = " - Successful!";

				},
				function ()
				{
					$scope.Display = " - Failed!";
				}
			);
		}
    }

	
 }
 
})();