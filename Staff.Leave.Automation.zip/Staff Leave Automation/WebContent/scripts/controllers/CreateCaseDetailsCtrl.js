(function () {
    'use strict';

    angular.module("app").controller("CreateCaseDetailsCtrl", ['$scope', '$rootScope', '$state', 'CaseService', fnCreateCaseDetailsCtrl]);
	
	function fnCreateCaseDetailsCtrl($scope, $rootScope, $state , CaseService) {
		
		$scope.$on('CREATE_CASE_SUBMIT', function(event) {
			//$scope.Message = 'CreateCaseDetailsCtrl received Id: ' + data.Id;
			alert('CreateCaseDetailsCtrl received Id: ');
			$scope.createCase(data.Id, data.casedetails);
		});		
		
        $scope.initializeController = function () {
			
        	$scope.Id = "";
			$scope.StaffName = "";
			$scope.StaffDesignation = "";
			$scope.RequestTypeLU = "";
			$scope.RequestTypeLUSelected = "";
			$scope.Description = "";
			$scope.Startdate = "";
			$scope.Returndate = "";
			$scope.HoursRequested = "";
			$scope.CaseCreated = false;
			$scope.SubmittedFlag = false;
			$scope.RequestTypeOptions = [
				{ label: 'Ordinary Vacation', value: 'Ordinary Vacation' },
				{ label: 'Bereavement', value: 'Bereavement' },
				{ label: 'Personal Days', value: 'Personal Days' },
				{ label: 'Sick Days', value: 'Sick Days' }
			  ];		
			
        }	
	   
        $scope.createCase = function (parentcaseid,thecase) {
			$scope.Title = "New Case Creation - ";
				var acase = {
					/*
					 * Id: $scope.Id,
                    StaffName: $scope.StaffName,
					StaffDesignation: $scope.StaffDesignation,
					RequestTypeLU: $scope.RequestTypeLUSelected.value,
					Description: $scope.Description,
					StartDate: $scope.StartDate,
					ReturnDate: $scope.ReturnDate,
					HoursRequested: $scope.HoursRequested
					 */
						Id: thecase.Id,
						StaffName: thecase.StaffName,
						StaffDesignation: thecase.StaffDesignation,
						RequestTypeLU: thecase.RequestTypeLU,
						Description: thecase.Description,
						StartDate : $scope.StartDate,
						ReturnDate: thecase.ReturnDate,
						HoursRequested: thecase.HoursRequested,
						ParentCaseId: parentcaseid
						
                };
			alert("Create Case details: " + JSON.stringify(acase));
            CaseService.createCaseDetails(acase).then(function (newcase) {
                //$scope.Id = newcase.Id;
                $scope.CaseCreated = true;
				
                $scope.Display = " Successful!";
            }, function ()
            {
                $scope.CaseCreated = false;
                $scope.Display = "Failed!";
            });
        }
		
    }
})();