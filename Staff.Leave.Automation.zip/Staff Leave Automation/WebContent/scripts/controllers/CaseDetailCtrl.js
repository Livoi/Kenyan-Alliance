/**
 * Created by Izone Ltd on 2/9/2016.
 */
(function () {
    'use strict';

    angular.module("app").controller("CaseDetailCtrl",['$scope','$routeParams','TaskService','CaseService',fnCaseDetailCtrl])


    function fnCaseDetailCtrl($scope,$routeParams,TaskService,CaseService) {

        $scope.initializeController = function () {
            $scope.TaskId = $routeParams.taskid;
            $scope.ProcessInstanceId = $routeParams.processinstanceid;
            $scope.SubmittedFlag = false;

            $scope.RequestTypeOptions = [
                { label: 'Ordinary Vacation', value: 'Ordinary Vacation' },
                { label: 'Bereavement', value: 'Bereavement' },
                { label: 'Personal Days', value: 'Personal Days' },
                { label: 'Sick Days', value: 'Sick Days' }
            ];

            //Get the Related Case
            CaseService.getHistoryVariables($routeParams.processinstanceid).then(
                function(casedata)
                {
                    $scope.TheCase = casedata;

                    angular.forEach($scope.RequestTypeOptions, function (requesttypeoptions) {
                        if(requesttypeoptions.value == $scope.TheCase.RequestTypeLU)
                        {
                            $scope.RequestTypeLUSelected = requesttypeoptions;
                        }
                    });

                }
            );


        }


    }

})();
