package com.camunda.CaseDetailsDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.camunda.DbUtil.*;
import com.camunda.model.CaseDetails;

public class CaseDetailsDao {
	
	private Connection connection;

    public CaseDetailsDao() {
        connection = DbUtil.getConnection();
    }

    public void addCaseDetails(CaseDetails casedetails) {
        try {
            PreparedStatement preparedStatement = connection
                    .prepareStatement("insert into CaseDetails(staffname,staffdesignation,requesttype,startdate,enddate,description,casereferencelu,hoursrequested) values (?, ?, ?, ?, ?, ?, ?, ?)");
            // Parameters start with 1
            preparedStatement.setString(1, casedetails.getStaffname());
            preparedStatement.setString(2, casedetails.getStaffdesignation());
            preparedStatement.setString(3, casedetails.getRequesttype());
            preparedStatement.setString(4, casedetails.getStartdate());
            preparedStatement.setString(5, casedetails.getEnddate());
            preparedStatement.setString(6, casedetails.getDescription());
            preparedStatement.setString(7, casedetails.getCasereferncelu());
            preparedStatement.setString(8, casedetails.getHoursrequested());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
    public List<CaseDetails> getAllCaseDetails() {
        List<CaseDetails> casedetails = new ArrayList<CaseDetails>();
        try {
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("select * from CaseDetails");
            while (rs.next()) {
            	CaseDetails casedetail = new CaseDetails();
            	casedetail.setCasereferncelu(rs.getString("casereferencelu"));
            	casedetail.setStaffname(rs.getString("staffname"));
            	casedetail.setStaffdesignation(rs.getString("staffdesignation"));
            	casedetail.setRequesttype(rs.getString("requesttype"));
            	casedetail.setStartdate(rs.getString("startdate"));
            	casedetail.setEnddate(rs.getString("enddate"));
            	casedetail.setHoursrequested(rs.getString("hoursrequested"));
            	casedetail.setDescription(rs.getString("description"));
            	casedetails.add(casedetail);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return casedetails;
    }
    
    public CaseDetails getCaseDetailsByGuid(String Guid) {
        CaseDetails casedetails = new CaseDetails();
        try {
            PreparedStatement preparedStatement = connection.
                    prepareStatement("select * from CaseDetails where casereferencelu=?");
            preparedStatement.setString(1, Guid);
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
            	casedetails.setCasereferncelu(rs.getString("casereferencelu"));
            	casedetails.setStaffname(rs.getString("staffname"));
            	casedetails.setStaffdesignation(rs.getString("staffdesignation"));
            	casedetails.setRequesttype(rs.getString("requesttype"));
            	casedetails.setStartdate(rs.getString("startdate"));
            	casedetails.setEnddate(rs.getString("enddate"));
            	casedetails.setHoursrequested(rs.getString("hoursrequested"));
            	casedetails.setDescription(rs.getString("description"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return casedetails;
    }
    
    public CaseDetails getTimeBankDetails(String staffid) {
        CaseDetails timebankdetails = new CaseDetails();
        try {
            PreparedStatement preparedStatement = connection.
                    prepareStatement("select * from timebank where employeeid=?");
            preparedStatement.setString(1, "1");
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
            	timebankdetails.setLeavedaysallocated(rs.getString("leavedaysallocated"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return timebankdetails;
    }

}
