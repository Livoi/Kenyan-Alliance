package com.camunda.model;


public class CaseDetails {
	
	private int caseid;
    private String staffname;
    private String staffdesignation;
    private String requesttype;
    private String startdate;
    private String enddate;
    private String description;
    private String casereferncelu;
    private String hoursrequested;
    
	public int getCaseid() {
		return caseid;
	}
	public void setCaseid(int caseid) {
		this.caseid = caseid;
	}
	public String getStaffname() {
		return staffname;
	}
	public void setStaffname(String staffname) {
		this.staffname = staffname;
	}
	public String getStaffdesignation() {
		return staffdesignation;
	}
	public void setStaffdesignation(String staffdesignation) {
		this.staffdesignation = staffdesignation;
	}
	public String getRequesttype() {
		return requesttype;
	}
	public void setRequesttype(String requesttype) {
		this.requesttype = requesttype;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}	
	 public String getCasereferncelu() {
		return casereferncelu;
	}
	public void setCasereferncelu(String casereferncelu) {
		this.casereferncelu = casereferncelu;
	}
	public String getHoursrequested() {
		return hoursrequested;
	}
	public void setHoursrequested(String hoursrequested) {
		this.hoursrequested = hoursrequested;
	}
	@Override
	    public String toString() {
	        return "CaseDetails [caseid=" + caseid + ", staffname=" + staffname
	                + ", staffdesignation=" + staffdesignation + ", requesttype=" + requesttype + ", startdate="
	                + startdate + ", enddate=" + enddate + ", description=" + description + ", "
	                		+ "casereferncelu=" + casereferncelu + ", hoursrequested="  + hoursrequested + "]";
	    } 

}
