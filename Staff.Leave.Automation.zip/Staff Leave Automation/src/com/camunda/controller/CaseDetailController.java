package com.camunda.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;




import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Enumeration;
import java.util.List;
import java.util.logging.Logger;

import org.json.JSONObject;

import com.camunda.CaseDetailsDao.*;
import com.camunda.model.*;
import com.google.gson.Gson;
import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

public class CaseDetailController extends HttpServlet{
	
private static final long serialVersionUID = 1L;
private CaseDetailsDao dao;
public static final Logger log = Logger.getLogger(CaseDetailController.class.getName());


public CaseDetailController() {
    super();
    dao = new CaseDetailsDao();
}



protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	PrintWriter out = response.getWriter();   
    
    Enumeration en = request.getParameterNames();
    
    while (en.hasMoreElements()) {
        
    String paramName = (String) en.nextElement();       
	
	String urlparameter = request.getParameter(paramName);
	/*log.info("Page Url : " + url.toString());*/
	
		if (urlparameter.equalsIgnoreCase("task")){
			
			List<CaseDetails> casedetails = dao.getAllCaseDetails();
			Gson gson = new Gson();
		    
		    String jcasedetails = gson.toJson(casedetails);
		    
		    response.setContentType("application/json, charset=UTF-8");
		    response.getWriter().write(jcasedetails);
			
		}else{ 
			
			CaseDetails casedetails = dao.getCaseDetailsByGuid(urlparameter);
			
			Gson gson = new Gson();
		    
		    String jcasedetails = gson.toJson(casedetails);
		    
		    response.setContentType("application/json, charset=UTF-8");
		    response.getWriter().write(jcasedetails);
			
		}
	
    }
    
}

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
	
	response.setContentType("application/json, charset=UTF-8");
	
	StringBuffer jb = new StringBuffer();
	  String line = null;
	  try {
	    BufferedReader reader = request.getReader();
	    while ((line = reader.readLine()) != null)
	      jb.append(line);
	  } catch (Exception e) { /*report an error*/ }

	  try {
	    JSONObject jsonObject = new JSONObject(jb.toString());
	    
	    CaseDetails casedetails = new CaseDetails();
	    
	    casedetails.setStaffname(jsonObject.getString("StaffName"));
	    casedetails.setStaffdesignation(jsonObject.getString("StaffDesignation"));
	    casedetails.setRequesttype(jsonObject.getString("RequestType"));
	    casedetails.setStartdate(jsonObject.getString("StartDate"));
	    casedetails.setEnddate(jsonObject.getString("EndDate"));
	    casedetails.setDescription(jsonObject.getString("Description"));
	    casedetails.setCasereferncelu(jsonObject.getString("CreateGuid"));
	    casedetails.setHoursrequested(jsonObject.getString("HoursRequested"));
	    
        dao.addCaseDetails(casedetails);
        
        log.info("Case Details : " + casedetails.toString());
        
        response.setContentType("application/json");// set content to json
	  	PrintWriter out = response.getWriter();
	  	out.print(casedetails);
	  	out.flush();
	    
	  } catch (ParseException e) {
	    // crash and burn
	    throw new IOException("Error parsing JSON request string");
	  }
}
}
